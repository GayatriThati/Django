from django.apps import AppConfig


class TraveloConfig(AppConfig):
    name = 'travelo'
